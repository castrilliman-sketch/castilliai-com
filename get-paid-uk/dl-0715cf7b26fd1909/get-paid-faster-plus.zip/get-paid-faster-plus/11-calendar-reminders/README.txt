CALENDAR REMINDERS (ITEM 11)

1. Open 11-reminder-generator.html in any web browser.
2. Enter the invoice number, customer, amount and DUE DATE.
3. Click "Download calendar file (.ics)". You get reminders on the due
   date (day 0) and at day 7, 14 and 30. There is also an optional
   reminder 5 days before the due date. Weekend dates move to Monday.
4. Open the downloaded .ics file to add it to Google Calendar, Outlook
   or Apple Calendar. Each reminder says which template to send.

11-sample-reminders.ics is an example for an invoice due 2 December 2026.
Nothing you type leaves your computer. General information, not legal advice.
