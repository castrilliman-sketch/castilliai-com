GET PAID FASTER PLUS - Item 13
Your 30-minute live invoice review
=====================================

Your Plus kit includes one 30-minute review of one invoice that is late,
or that you are about to send.

HOW TO BOOK
1. Email danwyatt398@gmail.com with the subject line: LIVE REVIEW
2. Include your order email or receipt number.
3. Attach the invoice (PDF), your quote, contract or terms if you have
   them, and your chase dates so far (or your tracker row). You can black
   out bank details.
4. Suggest three times that suit you. We will reply to confirm one.

WHAT WE LOOK AT
- Is the invoice complete: legal names, numbers, dates, PO, VAT details?
- Were payment terms agreed before work started, and do statutory interest
  and fixed-sum compensation apply?
- How much interest and compensation you can claim.
- Where you are in the chase sequence and which template to send next.
- Any red flags on your customer from Companies House or The Gazette.

PLEASE NOTE
This is practical guidance on using the kit. It is general information,
not legal advice, and we are not solicitors. We never contact your
customers. NexusAI t/a CastilliAI.
