ONE-PAGE GUIDE (ITEM 4)
04-plain-english-guide.pdf is the printable A4 page. The .html version has clickable GOV.UK links.
It covers everything from the first reminder to Money Claim Online. Facts checked 16 November 2026.
