INTEREST AND COMPENSATION CALCULATOR (ITEM 2)
Open 02-interest-calculator.html in any browser, or use 02-interest-calculator.xlsx (yellow cells = inputs).
Rates checked 16 November 2026: interest starting 1 Jul–31 Dec 2026 = 3.75% reference rate + 8% = 11.75% a year.
Bank Rate rose to 4% on 5 Nov 2026; if still 4% on 31 Dec 2026, interest starting 1 Jan–30 Jun 2027 = 12%.
Fixed-sum compensation per invoice: £40 (under £1,000), £70 (£1,000–£9,999.99), £100 (£10,000+).
B2B and public-authority customers only. General information, not legal advice.
