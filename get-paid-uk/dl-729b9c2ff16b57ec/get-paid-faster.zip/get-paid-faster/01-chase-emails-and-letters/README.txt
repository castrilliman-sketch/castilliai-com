CHASE EMAILS AND LETTERS — HOW TO USE THEM

Suggested sequence (adjust to the size of the debt and your relationship
with the customer):

  01-pre-due-reminder           3–7 days before the due date
  02-day-1-first-chase          First working day after the due date
  03-day-7-follow-up            About 7 days overdue
  04-day-14-firm-request        About 14 days overdue (interest mentioned, B2B only)
  05-day-30-final-notice        About 30 days overdue, with a last deadline
  06-final-request-...          After the final-notice deadline. Version 6A
                                for companies/LLPs/public bodies (14 days);
                                version 6B for individuals and sole traders
                                (Pre-Action Protocol for Debt Claims, 30 days).

The same six templates are in 00-all-six-templates.docx, ready to paste
onto your letterhead. The .txt files are easiest for pasting into email.

Practical tips
- Send from your own letterhead or email account.
- Replace every [bracketed] item and delete any paragraph that does not apply.
- Attach the invoice each time.
- Keep a dated copy of everything you send, and any replies (the invoice
  tracker has a column for each chase date).
- Only mention interest, compensation or court action you are entitled
  to and actually intend to follow through.
- Statutory interest and the fixed sum apply to business-to-business and
  business-to-public-authority contracts only, not consumers. They do not
  apply if your contract sets its own late-payment interest rate (with a
  public authority you cannot agree a rate lower than statutory).
- If the customer raises a genuine dispute, pause and deal with it in
  writing. Ask for any undisputed part to be paid meanwhile.
- If the customer is struggling, a written payment plan can beat a claim.
- Template 6 must stay clearly your letter, not a solicitor's letter or
  court form.


--------------------------------------------------
Get Paid Faster by NexusAI t/a CastilliAI (castilliai.com). General information,
not legal advice. England and Wales focus. Facts checked against GOV.UK and legislation.gov.uk on 16 November 2026.
