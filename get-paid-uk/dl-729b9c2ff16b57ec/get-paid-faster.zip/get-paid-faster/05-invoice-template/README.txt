INVOICE TEMPLATE (ITEM 5)
05-invoice-template.docx (Word / Google Docs) or 05-invoice-template.xlsx (works out totals, VAT and the due date).
Both include statutory late-payment interest and compensation wording. Put the same terms in your quote BEFORE
the job starts. An invoice can't add terms after the event. Delete the late-payment paragraph for consumers.
