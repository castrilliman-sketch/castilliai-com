ESCALATION DECISION TREE (ITEM 6)
One page (PDF to print, PNG for your phone or desktop). Start at the top when an invoice goes overdue and
work down: keep chasing, send the final letter, or issue a claim. Also shows when to pause or stop.
