INVOICE TRACKER (ITEM 3)
Open 03-invoice-tracker.xlsx and read the "How to use" sheet. Record each invoice, its status (dropdown) and the
date you sent each chase. It works out days overdue, interest, compensation and your NEXT ACTION for each invoice.
Delete the three example rows first. General information, not legal advice.
