Open get-paid-uk-guide.html in a browser and print it if you want a one-page paper copy (A4). It includes official GOV.UK links and the disclaimer.
