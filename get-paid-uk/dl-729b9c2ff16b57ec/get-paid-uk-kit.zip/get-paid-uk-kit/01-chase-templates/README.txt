CHASE TEMPLATES — HOW TO USE THEM

Suggested sequence (adjust to the size of the debt and your relationship
with the customer):

  1. 01-pre-due-reminder     A few days before the due date
  2. 02-day-1                First working day after the due date
  3. 03-day-7                About 7 days overdue
  4. 04-day-14               About 14 days overdue
  5. 05-day-30-final-notice  About 30 days overdue
  6. 06-final-request-...    After the deadline in the final notice

Practical tips
• Always send from your own letterhead or email account.
• Replace every [bracketed] item. Delete any paragraph that does not apply.
• Attach the invoice each time.
• Keep a dated copy of everything you send and any replies.
• Stay accurate. Do not claim fees, interest or legal steps you are not
  entitled to, or that you do not intend to follow through.
• Do not mention statutory interest or the fixed recovery fee if the
  customer is a consumer, or if your contract already sets a different
  late-payment interest rate (except that you cannot use a lower rate
  with a public authority).
• Template 6 must remain clearly your letter. Do not dress it up as a
  solicitor's letter or a court form.
• If the invoice is genuinely disputed, pause the chase and deal with
  the dispute in writing. Interest and recovery fees are not usually
  appropriate while a genuine dispute is being resolved.
• If the customer is struggling, a clear instalment plan in writing can
  be better than an immediate claim. Get any plan in writing.
